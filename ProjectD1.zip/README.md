# Project D: Twitter Data Analysis
### Project Group D1
#### Group Members
- Minsoo Kim
- Rajeev Thundiyil 
- Christian Boroff 