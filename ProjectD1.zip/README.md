# Project D: Twitter Data Analysis
### Project Group D1
#### Group Members
- Minsoo Kim - Task 1
- Rajeev Thundiyil - Task 2
- Christian Boroff - Task 3